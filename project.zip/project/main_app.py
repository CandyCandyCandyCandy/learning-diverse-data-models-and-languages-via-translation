#!C:/Users/lx615/AppData/Local/Programs/Python/Python38-32/python

# Import Flask Library
from flask import Flask, render_template, request, session, url_for, redirect, flash
import mysql.connector
import datetime
from datetime import timedelta
import calendar
import pandas as pd

# from register import *
# Define a route to hello function
app = Flask(__name__)

# Configure MySQL
conn = mysql.connector.connect(host="localhost",user="root",passwd="12345678",database="551db")
print('Database Connected')

@app.route('/')
def hello():
    print('Turning to Hello')
    return render_template('index.html')

# Define route for login
@app.route('/login')
def login():
    return render_template('login.html')


# Define route for customer register
@app.route('/customer_register')
def customer_register():
    return render_template('customer_register.html')

# Authenticates the register
@app.route('/register_customer_auth', methods=['GET', 'POST'])
def register_customer_auth():
    # grabs information from the forms
    email = request.form['email']
    name = request.form['name']
    password = request.form['password']
    phone_number = request.form['phone_number']
    print(email, name, password)

    cursor = conn.cursor()
    # executes query
    query = "SELECT * FROM user WHERE email = \'{}\'"
    cursor.execute(query.format(email))
    # stores the results in a variable
    data = cursor.fetchone()

    error = None
    if(data):
        # If the previous query returns data, then user exists
        session['error'] = "This user already exists"
        return render_template('customer_register.html', error = session['error'])
    else:
        ins = "INSERT INTO user VALUES(\'{}\', \'{}\',\'{}\',\'{}\')"
        cursor.execute(ins.format(email, name, password, phone_number))
        conn.commit()
        cursor.close()
        flash("You are logged in")
        return render_template('index.html')


# Authenticates the login
@app.route('/loginAuth', methods=['GET', 'POST'])
def loginAuth():

    name = request.form['name']
    password = request.form['password']
    # cursor used to send queries
    cursor = conn.cursor()
    # executes query
    query = "SELECT * FROM user WHERE name = \'{}\' and password = \'{}\'"
    cursor.execute(query.format(name, password))
    # stores the results in a variable
    data = cursor.fetchall()
    # use fetchall() if you are expecting more than 1 data row
    cursor.close()
    session['error'] = None
    if data:
        # creates a session for the the user
        # session is a built in

        print('>>you have logged in')
        session['user'] = name
        return redirect(url_for('customer_home'))
        # elif
    else:
        # returns an error message to the html page
        session['error'] = 'Invalid login or username'
        return render_template('login.html', error=session['error'])

#customer
@app.route('/customer_home')
def customer_home():
    user = session['user']


    return render_template('customer_home.html', username=user)

@app.route('/customer_home',methods=['GET', 'POST'])
def select_all():
    try:
        tablename =  request.form['table_name']

        query = 'select * from ' + tablename
        cursor = conn.cursor()
        cursor.execute(query)
        data =  cursor.fetchall()
        return render_template('customer_home.html',table_name = tablename,sql = query,output = data)
    except:
        return render_template('customer_home.html')
    
    
@app.route('/customer_home2',methods=['GET', 'POST'])
def select_by_condition():
    try:
        columnname =  request.form['column_name']

        tablename2 =  request.form['table_name2']
        query2 = 'select '+str(columnname) + ' from '+ str(tablename2)
        cursor = conn.cursor()
        cursor.execute(query2)
        data =  cursor.fetchall()
        return render_template('customer_home.html',column_name = columnname, table_name2 = tablename2,sql2 = query2,output2 = data)
    except:
        return render_template('customer_home.html')
        
@app.route('/customer_home4',methods=['GET', 'POST'])
def select_by_restriction():
    try:
        columnname3 =  request.form['column_names_3']
        tablename3 =  request.form['table_3']
        col = request.form['column_3']
        rel = request.form['relation_3']
        rel = rel.strip()
        num = request.form['value_3']
        if num.isnumeric() == True:
            if rel == 'start from':
                query3 = 'select '+str(columnname3) + ' from '+ str(tablename3)+ ' where ' +str(col) +' ' + 'Like ' +"'" +str(num) +'%' +"'"
                cursor = conn.cursor()
                cursor.execute(query3)
                data =  cursor.fetchall()
                return render_template('customer_home.html',column_names_3 = columnname3, table_3 = tablename3, column_3 = col, value_3 = num, sql3 = query3,output3 = data)
            elif rel == 'end at':
                query3 = 'select '+str(columnname3) + ' from '+ str(tablename3)+ ' where ' +str(col) +' ' + 'Like ' +"'" + '%' + str(num) +"'"
                cursor = conn.cursor()
                cursor.execute(query3)
                data =  cursor.fetchall()
                return render_template('customer_home.html',column_names_3 = columnname3, table_3 = tablename3, column_3 = col, value_3 = num, sql3 = query3,output3 = data)
            else:
                relation_dict = {'less than':'<', 'greater than':'>', 'equal to':'=','less than or equal to':'<=', 'greater than or equal to':'>=', 'contains':'Like'}

                query3 = 'select '+str(columnname3) + ' from '+ str(tablename3)+ ' where ' +str(col) +' ' + str(relation_dict[rel]) +' ' + str(num)
                print(query3)
                cursor = conn.cursor()
                cursor.execute(query3)
                data =  cursor.fetchall()
                
                return render_template('customer_home.html',column_names_3 = columnname3, table_3 = tablename3, column_3 = col, relation_3 = rel, value_3 = num, sql3 = query3,output3 = data)
        else:
            if rel == 'start from':
                query3 = 'select '+str(columnname3) + ' from '+ str(tablename3)+ ' where ' +str(col) +' ' + 'Like ' +"'" +str(num) +'%' +"'"
                cursor = conn.cursor()
                cursor.execute(query3)
                data =  cursor.fetchall()
                return render_template('customer_home.html',column_names_3 = columnname3, table_3 = tablename3, column_3 = col, value_3 = num, sql3 = query3,output3 = data)
            elif rel == 'end at':
                query3 = 'select '+str(columnname3) + ' from '+ str(tablename3)+ ' where ' +str(col) +' ' + 'Like ' +"'" + '%' + str(num) +"'"
                cursor = conn.cursor()
                cursor.execute(query3)
                data =  cursor.fetchall()
                return render_template('customer_home.html',column_names_3 = columnname3, table_3 = tablename3, column_3 = col, value_3 = num, sql3 = query3,output3 = data)
            else:
                relation_dict = {'less than':'<', 'greater than':'>', 'equal to':'=','less than or equal to':'<=', 'greater than or equal to':'>=', 'contains':'Like'}

                query3 = 'select '+str(columnname3) + ' from '+ str(tablename3)+ ' where ' +str(col) +' ' + str(relation_dict[rel]) +' ' +"'"+ str(num) + "'"
                print(query3)
                cursor = conn.cursor()
                cursor.execute(query3)
                data =  cursor.fetchall()
                
                return render_template('customer_home.html',column_names_3 = columnname3, table_3 = tablename3, column_3 = col, relation_3 = rel, value_3 = num, sql3 = query3,output3 = data)
    except:
        return render_template('customer_home.html')
    
@app.route('/customer_home5',methods=['GET', 'POST'])
def select_by_restriction_more():
    try:
        relation_dict = {'less than':'<', 'greater than':'>', 'equal to':'=','less than or equal to':'<=', 'greater than or equal to':'>='}
        columnname3 =  request.form['column_names_3']
        tablename3 =  request.form['table_3']
        col = request.form['column_3']
        rel = request.form['relation_3']
        rel = rel.strip()
        num = request.form['value_3']
        bool = request.form['bool_comparsions']
        col2 = request.form['column_33']
        rel2 = request.form['relation_33']
        rel2 = rel2.strip()
        num2 = request.form['value_33']
        if num.isnumeric() == True and num2.isnumeric() == True:
            query4 = 'select '+str(columnname3) + ' from '+ str(tablename3)+ ' where ' +str(col) +' ' + str(relation_dict[rel])+ ' '  +str(num)  +' '+ str(bool)+' ' +str(col2) +' ' + str(relation_dict[rel2])+ ' '  +str(num2)
        elif num.isnumeric() == False and num2.isnumeric() == True:
            query4 = 'select '+str(columnname3) + ' from '+ str(tablename3)+ ' where ' +str(col) +' ' + str(relation_dict[rel])+ ' ' + "'" +str(num) + "'" +' '+ str(bool)+' ' +str(col2) +' ' + str(relation_dict[rel2])+ ' '  +str(num2)
        elif num2.isnumeric() == False and num.isnumeric() == True:
            query4 = 'select '+str(columnname3) + ' from '+ str(tablename3)+ ' where ' +str(col) +' ' + str(relation_dict[rel])+ ' '  +str(num)  +' '+ str(bool)+' ' +str(col2) +' '  + str(relation_dict[rel2])  + ' ' + "'" +str(num2)+ "'"
        else:
            query4 = 'select '+str(columnname3) + ' from '+ str(tablename3)+ ' where ' +str(col) +' ' + str(relation_dict[rel])+ ' '  +str(num)  +' '+ str(bool)+' ' + "'" +str(col2) + "'"+' '  + str(relation_dict[rel2])  + ' ' + "'" + str(num2) + "'"
        print(query4)
        cursor = conn.cursor()
        cursor.execute(query4)
        data =  cursor.fetchall()
        return render_template('customer_home.html',column_names_3 = columnname3, table_3 = tablename3, column_3 = col, relation_3 = rel, value_3 = num, bool_comparsions = bool,column_33 = col2, relation_33 = rel2, value_33 = num2, sql4 = query4, output4 = data)

    except:
        return render_template('customer_home.html')
    
@app.route('/customer_home6',methods=['GET', 'POST'])
def select_by_group():
    try:
        relation_dict = {'less than':'<', 'greater than':'>', 'equal to':'=','less than or equal to':'<=', 'greater than or equal to':'>='}
        columnname3 =  request.form['column_names_3']
        tablename3 =  request.form['table_3']
        col = request.form['column_3']
        rel = request.form['relation_3']
        rel = rel.strip()
        num = request.form['value_3']
        groupby = request.form['group']
        col2 = request.form['column_33']
        rel2 = request.form['relation_33']
        rel2 = rel2.strip()
        num2 = request.form['value_33']
        
        if num.isnumeric() == True and num2.isnumeric() == True:
            query5 = 'select '+str(columnname3) + ' from '+ str(tablename3)+ ' where ' +str(col) +' ' + str(relation_dict[rel])+ ' '  +str(num)  +' '+ 'group by'+' '+str(groupby) +' having ' + str(col2) +' ' + str(relation_dict[rel2])+ ' '  +str(num2)
        elif num.isnumeric() == False and num2.isnumeric() == True:
            query5 = 'select '+str(columnname3) + ' from '+ str(tablename3)+ ' where ' +str(col) +' ' + str(relation_dict[rel])+ ' ' + "'" +str(num) + "'" +' '+ 'group by'+' '+str(groupby) +' having ' + str(col2) +' ' + str(relation_dict[rel2])+ ' '  +str(num2)
        elif num2.isnumeric() == False and num.isnumeric() == True:
            query5 = 'select '+str(columnname3) + ' from '+ str(tablename3)+ ' where ' +str(col) +' ' + str(relation_dict[rel])+ ' ' +str(num)  +' '+ 'group by'+' '+str(groupby) +' having ' + str(col2) +' ' + str(relation_dict[rel2])+ ' ' + "'" +str(num2) + "'"
        else:
            query5 = 'select '+str(columnname3) + ' from '+ str(tablename3)+ ' where ' +str(col) +' ' + str(relation_dict[rel])+ ' ' + "'" +str(num) + "'" +' '+ 'group by'+' '+str(groupby) +' having ' + str(col2) +' ' + str(relation_dict[rel2])+ ' ' + "'" +str(num2) + "'"
            
        print(query5)
        cursor = conn.cursor()
        cursor.execute(query5)
        data =  cursor.fetchall()
        return render_template('customer_home.html',column_names_3 = columnname3, table_3 = tablename3, column_3 = col, relation_3 = rel, value_3 = num, group = groupby, column_33 = col2, relation_33 = rel2, value_33 = num2, sql5 = query5,output5 = data)
    except:
        return render_template('customer_home.html')

#pandas
@app.route('/customer_home333',methods=['GET', 'POST'])

def df_all ():
    try:
        dataframe = request.form['dataframe_h1']
        result = dataframe
        query = 'select * from '+ str(dataframe)
        cursor = conn.cursor()
        cursor.execute(query)
        data =  cursor.fetchall()
        return render_template('customer_home.html',dataframe_h1 = dataframe, pandas1 = result, output_p1 = data)
    except:
        return render_template('customer_home.html')
@app.route('/customer_home33',methods=['GET', 'POST'])
def df_one_column ():
    try:
        dataframe = request.form['dataframe_h2']
        column_names = request.form['column_names_h2']
        result = dataframe +"['"+column_names+"']"
        query = 'select '+str(column_names) + ' from '+ str(dataframe)
        cursor = conn.cursor()
        cursor.execute(query)
        data =  cursor.fetchall()
        return render_template('customer_home.html',column_names_h2 = column_names, dataframe_h2 = dataframe, pandas = result, output_p = data)
    except:
        return render_template('customer_home.html')
        
@app.route('/customer_home3',methods=['GET', 'POST'])
def from_natural_to_df():
  relation_dict2 = {'less than':'<', 'greater than':'>', 'equal to':'=','less than or equal to':'<=', 'greater than or equal to':'>='}
  commands = [] # a list that holds all possible commands
  result = None # an object that holds the result after executing the command
  error = False
  column_names = request.form['column_names_h']
  conditions = []
  bool_comparsions = [request.form['bool_comparsions_h']]
  dataframe = request.form['dataframe_h']
  column1 = request.form['column_h']
  relation1 = request.form['relation_h']
  value1 = request.form['value_h']
  column2 = request.form['column_h2']
  relation2 = request.form['relation_h2']
  value2 = request.form['value_h2']
  conditions.append((column1,relation1,value1))
  conditions.append((column2,relation2,value2))
# simply then return the command that will display the entire dataframe
  if column_names is None:
    if conditions ==[(),()]:
      if bool_comparsions is not None:
        commands.append('error: unexpected argument')
        
        return render_template('customer_home.html',commands = comm)
      else:
        commands.append(dataframe)
        return render_template('customer_home.html', dataframe_h = dataframe,column_h = column1,relation_h =relation1,value_h=value1,column_h2=column2,relation_h2 =relation2,value_h2=value2, column_names_h= column_names,comm =commands )
    # there are conditions and no column name
    # which means df[ df[condition]==value ]
    else:
      # check argument error
      len_cond = len(conditions)
      if bool_comparsions is None:
        len_comp = 0
        bool_comparsions = []
      else:
        len_comp = len(bool_comparsions)
      if len_comp+1 != len_cond:
        # c1 comparsion c2: 'mpg' < 500
        # mpg is c1, < is comparison, 500 is c2
        commands.append('error: conditions have to be one more than comparsions')
        return render_template('customer_home.html', dataframe_h = dataframe,column_h = column1,relation_h =relation1,value_h=value1,column_h2=column2,relation_h2 =relation2,value_h2=value2, column_names_h= column_names,comm = commands )
      else:
        # cond_tuple = (col, relation, value)
        # col means column name
        # relation is: less than, greater than, equal, less than equal, greater than equal
        # value is the numerical value that c1 compares to
        relation_dict = {'less than':'<', 'greater than':'>', 'equal to':'==',\
                         'less than or equal to':'<=', 'greater than or equal to':'>='}
        comp_dict = {'and':'&', 'or':'|'}
        condition = ''
        df_cond_list = list()
        for i in range(len(conditions)):
          cond_tuple = conditions[i]
          col = cond_tuple[0]
          relation = relation_dict[cond_tuple[1]]
          value = cond_tuple[2]
          condition += '('+dataframe+'[' + '\''+col+'\'' +']' + relation + str(value) + ')'
          '''
          if relation == '<':
            df_cond = df[col]<value
          elif relation == '>':
            df_cond = df[col]>value
          elif relation == '==':
            df_cond = df[col]==value
          elif relation == '<=':
            df_cond = df[col]<=value
          elif relation == '>=':
            df_cond = df[col]>=value
          df_cond_list.append(df_cond)
          '''

          if (len_comp != 0) and (i != len_cond-1):
            condition += ' ' + comp_dict[bool_comparsions[i]] + ' '
        
        commands.append(dataframe+'['+condition+']')
        commands.append(dataframe+'.loc['+condition+']')
        '''
        for df_cond in df_cond_list:
          result = dataset[df_cond]
        '''
        return render_template('customer_home.html', dataframe_h = dataframe,column_h = column1,relation_h=relation1,value_h=value1,column_h2=column2,relation_h2 =relation2,value_h2=value2, column_names_h= column_names,comm = commands)

  #column name is specified
  else:
    if conditions == [(),()]:


      '''column name is a list'''
      
      '''if isinstance(column_names, list):

        # check each column name is valid
        for col_name in column_names:
          if col_name not in data.columns:
            commands.append(f'error: column name {col_name} does not exist')
            error = True
        # if there is an error, return error msg and null result, otherwise return
        # the command and the result
        if error:
          return render_template('customer_home.html',commands = comm)
        else:
      commands.append(dataframe+'.loc[:,{column_names}]')
      commands.append(dataframe+'[{column_names}]')
      result = dataset[column_names]
      return render_template('customer_home.html', dataframe_h = dataframe,column_h = column1,relation_h =relation1,value_h=value1,column_h2=column2,relation_h2 =relation2,value_h2=value2,column_names_h, column_names,commands = comm)


      else:
        # if the column name is valid, return the command, otherwise raise error
        
        if column_names not in data.columns:
          commands.append(f'error: column name {column_names} does not exist')
          error = True
        # if there is an error, return error msg and null result, otherwise return
        # the command and the result
        if error:
          return commands, result
        else:
          # three possible commands for retrieving column data from dataframe
          '''
      commands.append(dataframe+'.loc[:,'+column_names+']')
      commands.append(dataframe+'['+column_names+']')
      commands.append(dataframe+'.'+column_names+'')
      '''result = dataset[column_names]'''
      return render_template('customer_home.html', dataframe_h = dataframe,column_h = column1,relation_h =relation1,value_h=value1,column_h2=column2,relation_h2 =relation2,value_h2=value2, column_names_h=column_names,comm = commands )
    else:
      # conditions are also specified
      # which means which means df[ df[condition]==value ]['column name']
      # check argument error
      len_cond = len(conditions)
      if bool_comparsions is None:
        len_comp = 0
        bool_comparsions = []
      else:
        len_comp = len(bool_comparsions)
      if len_comp+1 != len_cond:
        print(2)
        # c1 comparsion c2: 'mpg' < 500
        # mpg is c1, < is comparison, 500 is c2
        commands.append('error: conditions have to be one more than comparsions')
        return render_template('customer_home.html', dataframe_h = dataframe,column_h = column1,relation_h =relation1,value_h=value1,column_h2=column2,relation_h2 =relation2,value_h2=value2, column_names_h=column_names,comm = commands )
      else:
        # cond_tuple = (col, relation, value)
        # col means column name
        # relation is: less than, greater than, equal, less than equal, greater than equal
        # value is the numerical value that c1 compares to
        relation_dict = {'less than':'<', 'greater than':'>', 'equal to':'==',\
                         'less than or equal to':'<=', 'greater than or equal to':'>='}
        comp_dict = {'and':'&', 'or':'|'}
        condition = ''
        df_cond_list = list()
        for i in range(len(conditions)):
          cond_tuple = conditions[i]
          col = cond_tuple[0]
          relation = relation_dict[cond_tuple[1]]
          value = cond_tuple[2]
          condition += '('+dataframe+'[' + '\''+col+'\'' +']' + relation + str(value) + ')'

          '''if relation == '<':
            df_cond = df[col]<value
          elif relation == '>':
            df_cond = df[col]>value
          elif relation == '==':
            df_cond = df[col]==value
          elif relation == '<=':
            df_cond = df[col]<=value
          elif relation == '>=':
            df_cond = df[col]>=value
          df_cond_list.append(df_cond)'''

          if (len_comp != 0) and (i != len_cond-1):
            condition += ' ' + comp_dict[bool_comparsions[i]] + ' '
  
        commands.append(str(dataframe+'['+condition+'][\''+column_names+'\']'))
        commands.append(str(dataframe+'.loc['+condition+'][\''+column_names+'\']'))
        '''
        for df_cond in df_cond_list:
          result = dataset[df_cond]
        result = result[column_names]
        '''
        pandas3 = 'select '+column_names+' from '+ dataframe + ' where '+column1 + ' ' + relation_dict2[relation1] +' ' +"'"+ value1 +"'" +' '+ bool_comparsions[0] +' ' +column2 + ' ' + relation_dict2[relation2] +' ' +"'"+ value2 +"'"
        print(pandas3)
        cursor = conn.cursor()
        cursor.execute(pandas3)
        data3 =  cursor.fetchall()
        return render_template('customer_home.html', dataframe_h = dataframe,column_h = column1,relation_h =relation1,value_h=value1,column_h2=column2,relation_h2 =relation2,value_h2=value2,output_p3 = data3,
        column_names_h=column_names,comm = commands[0]+'  or you can wirte:  '+commands[1])

@app.route('/customer_home_tran1',methods=['GET', 'POST'])
def from_sql_to_df_select_from():
    table = request.form['trans_table1']
    projection = request.form['trans_pro1']
    projection = projection.split(',')
    
    commands = [] # a list that holds all possible commands
    result = None # an object that holds the sql commands
    error = False
    cursor = conn.cursor()
    #get all columns name
    all_columns_query = f'select column_name from information_schema.columns where table_name=\'{table}\''
    cursor.execute(all_columns_query)
    all_columns_result = cursor.fetchall()
    columns_df = pd.DataFrame(all_columns_result)
    all_columns = list(columns_df[0])


    #error checking
    if isinstance(projection, list):
        for column in projection:
            if column not in all_columns and column != '*':
                commands.append(f'error: specified column name {column} does not exist')
                error = True
                break
    else:
        commands.append(f'error: wrong column type passed, must be a list, got {type(projection)}')
        error = True
        
    if error == True:
    
        return render_template('customer_home.html', trans_table1 = table,trans_pro1 = projection, co1 = commands[0],result1 = result)

    #translation
    if error == False:
        if projection[0] == '*': #SELECT *
            commands.append(str(table))
            commands.append('no second choice')
            query = f'SELECT * FROM {table};'
            result = query
            cursor.execute(query)
            data11 =  cursor.fetchall()
            
        else:
            commands.append(table+'[{}]'.format(projection))
            commands.append(table+'.iloc[:,{}]'.format(projection))
            
            projection_list = ', '.join(projection)
            query = f'SELECT {projection_list} FROM {table};'
            result = query
            cursor.execute(query)
            data11 =  cursor.fetchall()

        return render_template('customer_home.html', trans_table1 = table,trans_pro1 = projection, co1 = commands[0], co2 = commands[1],result1 = result,data_tran1 = data11)

@app.route('/customer_home_tran2',methods=['GET', 'POST'])
def from_sql_to_df_select_from_where():
    dict = {'and':'&','or':'|'}
    cursor = conn.cursor()
    table = request.form['trans_table2']
    projection = request.form['trans_pro2']
    projection = projection.split(',')
    con1 = request.form['cond1']
    con2 = request.form['cond2']
    con3 = request.form['cond3']
    tuple1 = (con1,con2,con3)
    
    con4 = request.form['cond4']
    con5 = request.form['cond5']
    con6 = request.form['cond6']
    tuple2 = (con4,con5,con6)
    
    conditions = []
    conditions.append(tuple1)
    conditions.append(tuple2)
    
    bool_c = request.form['bool']
    bool_comp = []
    bool_comp.append(bool_c)
    
    
    commands = [] # a list that holds all possible commands
    result = None # an object that holds the result after executing the command
    error = False
    
    #get all columns name
    all_columns_query = f'select column_name from information_schema.columns where table_name=\'{table}\''
    cursor.execute(all_columns_query)
    all_columns_result = cursor.fetchall()
    columns_df = pd.DataFrame(all_columns_result)
    all_columns = list(columns_df[0])

    #error checking
    if isinstance(projection, list):
        for column in projection:
            if column not in all_columns and column != '*':
                commands.append(f'error: specified column name {column} does not exist')
                error = True
                break
    else:
        commands.append(f'error: wrong column type passed, must be a list, got {type(projection)}')
        error = True

    #error checking for conditions
    if isinstance(conditions, list):
        for three_tuple in conditions:
            if three_tuple[0] not in all_columns:
                commands.append(f'error: specified column name \'{three_tuple[0]}\' in {three_tuple} does not exist in the table')
                error = True
            if three_tuple[1] not in ['>', '=', '<', '>=', '<=']:
                commands.append(f'error: invalid unary operator \'{three_tuple[1]}\' in {three_tuple}')
                error = True
    else:
        commands.append(f'error: conditions must be a list, got \'{type(conditions)}\' instead.')
        error = True

    #error checking for bool_comp
    if isinstance(bool_comp, list):
        if len(bool_comp) != len(conditions) - 1:
            commands.append(f'error: conditions have to be one more than boolean operators')
            error = True
        else:
            for bool_operator in bool_comp:
                if bool_operator not in ['and', 'or']:
                    commands.append(f'error: invalid boolean operator, expect and/or , got \'{bool_operator}\' instead.')
                    error = True
                    break
    else:
        commands.append(f'error: bool_comp must be a list, got \'{type(bool_comp)}\' instead.')
        error = True
    
    if error == True:
        return render_template('customer_home.html', trans_table2 = table,trans_pro2 = projection,cond1 = con1,cond2=con2,cond3=con3,cond4=con4,cond5=con5,cond6=con6,bool=bool_c,co3 = commands[0],result2 = result)
    
    #translation
    if error == False:
        cond_list = []
        sql_cond = []
        for con in conditions:
            col = con[0]
            if con[1] == '=':
                comp = '=='
            else:
                comp = con[1]
            comp_sql = con[1]
            value = con[2]
    
            if value.isnumeric() == False:
                condition = f'({table}[\'{col}\']{comp}\'{value}\')'
                sql_cond.append(f'{col} {comp_sql} \'{value}\'')
            else:
                condition = f'({table}[\'{col}\']{comp}{value})'
                sql_cond.append(f'{col} {comp_sql} {value}')
            cond_list.append(condition)

        #combine the multiple projection into one string
        for i in range(len(bool_comp)):
            if bool_comp[i] == 'and':
                bool_comp[i] = '&'
            elif bool_comp[i] == 'or':
                bool_comp[i] = '|'
        projection_clause = [None] * (len(cond_list)+len(bool_comp))
        projection_clause[::2] = cond_list
        projection_clause[1::2] = bool_comp
        combined_cond = ' '.join(projection_clause)
        
        bool_comp_sql = ['AND' if x=='and'or x=='&' else 'OR' for x in bool_comp]
        sql_where_clause =  [None] * (len(sql_cond)+len(bool_comp_sql))
        sql_where_clause[::2] = sql_cond
        sql_where_clause[1::2] = bool_comp_sql
        combined_sql_where_clause = ' '.join(sql_where_clause)
        
        #append command
        if projection[0] == '*':
            commands.append(f'{table}[{combined_cond}]')
            query = f'SELECT * FROM {table} WHERE {combined_sql_where_clause};'
            result = query
            cursor.execute(query)
            data22 =  cursor.fetchall()
        else:
            #get result
            projection_list = ', '.join(projection)
            commands.append(f'{table}[{combined_cond}][{projection}]')
            query = f'SELECT {projection_list} FROM {table} WHERE {combined_sql_where_clause};'
            result = query
            cursor.execute(query)
            data22 =  cursor.fetchall()
    print(commands)
    return render_template('customer_home.html', trans_table2 = table,trans_pro2 = projection,cond1 = con1,cond2=con2,cond3=con3,cond4=con4,cond5=con5,cond6=con6,bool=bool_c,co3 = commands[0],result2 = result,data_tran2 = data22)
    

@app.route('/customer_home_tran3',methods=['GET', 'POST'])
def from_sql_to_df_select_from_where_groupby():

    cursor = conn.cursor()
    table = request.form['trans_table3']
    projection = request.form['trans_pro3']
    projection = projection.split(',')
    con1 = request.form['cond13']
    con2 = request.form['cond23']
    con3 = request.form['cond33']
    tuple1 = (con1,con2,con3)
    
    con4 = request.form['cond43']
    con5 = request.form['cond53']
    con6 = request.form['cond63']
    tuple2 = (con4,con5,con6)
    
    conditions = []
    conditions.append(tuple1)
    conditions.append(tuple2)
    

    group = request.form['group_tran']
    groupby_cond = group.split(',')
    
    
    bool_c = request.form['bool3']
    bool_comp = []
    bool_comp.append(bool_c)
    
    
    commands = [] # a list that holds all possible commands
    result = None # an object that holds the result after executing the command
    error = False
    
    #get all columns name
    all_columns_query = f'select column_name from information_schema.columns where table_name=\'{table}\''
    cursor.execute(all_columns_query)
    all_columns_result = cursor.fetchall()
    columns_df = pd.DataFrame(all_columns_result)
    all_columns = list(columns_df[0])

    #error checking
    if isinstance(projection, list):
        for column in projection:
            if column not in all_columns and column !='*':
                commands.append(f'error: specified column name {column} does not exist')
                error = True
                break
    else:
        commands.append(f'error: wrong column type passed, must be a list, got {type(projection)}')
        error = True

    #error checking for conditions
    if isinstance(conditions, list):
        for three_tuple in conditions:
            if three_tuple[0] not in all_columns:
                commands.append(f'error: specified column name \'{three_tuple[0]}\' in {three_tuple} does not exist in the table')
                error = True
            if three_tuple[1] not in ['>', '=', '<', '>=', '<=']:
                commands.append(f'error: invalid unary operator \'{three_tuple[1]}\' in {three_tuple}')
                error = True
    else:
        commands.append(f'error: conditions must be a list, got \'{type(conditions)}\' instead.')
        error = True

    #error checking for bool_comp
    if isinstance(bool_comp, list):
        if len(bool_comp) != len(conditions) - 1:
            commands.append(f'error: conditions have to be one more than boolean operators')
            error = True
        else:
            for bool_operator in bool_comp:
                if bool_operator not in ['and', 'or']:
                    commands.append(f'error: invalid boolean operator, expect & or |, got \'{bool_operator}\' instead.')
                    error = True
                    break
    else:
        commands.append(f'error: bool_comp must be a list, got \'{type(bool_comp)}\' instead.')
        error = True
    print(groupby_cond)
    #error checking for groupby
    if isinstance(groupby_cond, list):
        for column_name in groupby_cond:
            if column_name not in all_columns:
                commands.append(f'error: specified column name \'{column_name}\' does not exist in the table')
                error = True
    
    else:
        commands.append(f'error: groupby_cond must be a list of column names, got {type(groupby_cond)} instead.')
        error = True
    if error == True:
        return render_template('customer_home.html', trans_table3 = table,trans_pro3 = projection,cond13 = con1,cond23=con2,cond33=con3,cond43=con4,cond53=con5,cond63=con6,bool3=bool_c,co33 = commands[0],result3 = result,group_tran = group)
    
    #translation
    if error == False:
        cond_list = []
        sql_cond = []
        for con in conditions:
            col = con[0]
            if con[1] == '=':
                comp = '=='
            else:
                comp = con[1]
            comp_sql = con[1]
            value = con[2]
    
            if value.isnumeric() == False:
                condition = f'({table}[\'{col}\']{comp}\'{value}\')'
                sql_cond.append(f'{col} {comp_sql} \'{value}\'')
            else:
                condition = f'({table}[\'{col}\']{comp}{value})'
                sql_cond.append(f'{col} {comp_sql} {value}')
            cond_list.append(condition)
        for i in range(len(bool_comp)):
            if bool_comp[i] == 'and':
                bool_comp[i] = '&'
            elif bool_comp[i] == 'or':
                bool_comp[i] = '|'
        #combine the multiple projection into one string
        projection_clause = [None] * (len(cond_list)+len(bool_comp))
        projection_clause[::2] = cond_list
        projection_clause[1::2] = bool_comp
        combined_cond = ' '.join(projection_clause)
        
        bool_comp_sql = ['AND' if x=='and' or x=='&' else 'OR' for x in bool_comp]
        sql_where_clause =  [None] * (len(sql_cond)+len(bool_comp_sql))
        sql_where_clause[::2] = sql_cond
        sql_where_clause[1::2] = bool_comp_sql
        combined_sql_where_clause = ' '.join(sql_where_clause)
        
        groupby_list = ', '.join(groupby_cond)
        
        #append command
        if projection[0] == '*':
            commands.append(f'{table}[{combined_cond}].groupby({groupby_cond})')
            query = f'SELECT * FROM {table} WHERE {combined_sql_where_clause} GROUP BY {groupby_list};'
            result = query
            cursor.execute(query)
            data33 =  cursor.fetchall()
            
        else:
            #get result
            projection_list = ', '.join(projection)
            commands.append(f'{table}[{combined_cond}].groupby({groupby_cond})[{projection}]')
            query = f'SELECT {projection_list} FROM {table} WHERE {combined_sql_where_clause} GROUP BY {groupby_list};'
            result = query
            cursor.execute(query)
            data33 =  cursor.fetchall()
            
    return render_template('customer_home.html', trans_table3 = table,trans_pro3 = projection,cond13 = con1,cond23=con2,cond33=con3,cond43=con4,cond53=con5,cond63=con6,bool3=bool_c,co33 = commands[0],result3 = result,group_tran = group,data_tran3 = data33)


@app.route('/customer_home_tran4',methods=['GET', 'POST'])
def from_sql_to_df_select_from_where_groupby_orderby():
    
    cursor = conn.cursor()
    table = request.form['trans_table4']
    projection = request.form['trans_pro4']
    projection = projection.split(',')
    con1 = request.form['cond133']
    con2 = request.form['cond233']
    con3 = request.form['cond333']
    tuple1 = (con1,con2,con3)
    
    con4 = request.form['cond433']
    con5 = request.form['cond533']
    con6 = request.form['cond633']
    tuple2 = (con4,con5,con6)
    
    conditions = []
    conditions.append(tuple1)
    conditions.append(tuple2)
    

    group = request.form['group_tran3']
    groupby_cond = group.split(',')
    
    
    bool_c = request.form['bool33']
    bool_comp = []
    bool_comp.append(bool_c)
    
    
    col = request.form['coll']
    orderby = request.form['order']
    orderby_cond = []
    if orderby == 'ASC':
        tuple = (col,True)
        orderby_cond.append(tuple)
    elif orderby == 'DESC':
        tuple = (col,False)
        orderby_cond.append(tuple)

    commands = [] # a list that holds all possible commands
    result = None # an object that holds the result after executing the command
    error = False
    
    #get all columns name
    all_columns_query = f'select column_name from information_schema.columns where table_name=\'{table}\''
    cursor.execute(all_columns_query)
    all_columns_result = cursor.fetchall()
    columns_df = pd.DataFrame(all_columns_result)
    all_columns = list(columns_df[0])

    #error checking
    if isinstance(projection, list):
        for column in projection:
            if column not in all_columns and column!='*':
                commands.append(f'error: specified column name {column} does not exist')
                error = True
                break
    else:
        commands.append(f'error: wrong column type passed, must be a list, got {type(projection)}')
        error = True

    #error checking for conditions
    if isinstance(conditions, list):
        for three_tuple in conditions:
            if three_tuple[0] not in all_columns:
                commands.append(f'error: specified column name \'{three_tuple[0]}\' in {three_tuple} does not exist in the table')
                error = True
            if three_tuple[1] not in ['>', '=', '<', '>=', '<=']:
                commands.append(f'error: invalid unary operator \'{three_tuple[1]}\' in {three_tuple}')
                error = True
    else:
        commands.append(f'error: conditions must be a list, got \'{type(conditions)}\' instead.')
        error = True

    #error checking for bool_comp
    if isinstance(bool_comp, list):
        if len(bool_comp) != len(conditions) - 1:
            commands.append(f'error: conditions have to be one more than boolean operators')
            error = True
        else:
            for bool_operator in bool_comp:
                if bool_operator not in ['and', 'or']:
                    commands.append(f'error: invalid boolean operator, expect & or |, got \'{bool_operator}\' instead.')
                    error = True
                    break
    else:
        commands.append(f'error: bool_comp must be a list, got \'{type(bool_comp)}\' instead.')
        error = True
        
    #error checking for groupby
    if isinstance(groupby_cond, list):
        for column_name in groupby_cond:
            if column_name not in all_columns:
                commands.append(f'error: specified column name \'{column_name}\' does not exist in the table')
                error = True
    else:
        commands.append(f'error: groupby_cond must be a list of column names, got {type(groupby_cond)} instead.')
        error = True
    '''
    #error checking for orderby
    if isinstance(orderby_cond, list):
        for two_tuple in orderby_cond:
            if not isinstance(two_tuple, tuple):
                commands.append(f'error: each element in the list must be a two-tuple, got {type(two_tuple)} instead.')
                error = True
    else:
        commands.append(f'error: orderby_cond must be a list of column names and boolean values, got {type(orderby_cond)} instead.')
        error = True
    '''
    if error == True:
        return render_template('customer_home.html', trans_table4 = table,trans_pro4 = projection,cond133 = con1,cond233=con2,cond333=con3,cond433=con4,cond533=con5,cond633=con6,bool33=bool_c,co333 = commands[0],result4 = result,group_c3 = group,order = orderby,coll = col)
    #translation
    if error == False:
        
        sort_value_list_by = []
        sort_value_list_ascending = []
        orderby_list = []
        for two_tuple in orderby_cond:
            if two_tuple[1] == True:
                orderby_list.append(f'{two_tuple[0]} ASC')
                sort_value_list_by.append(two_tuple[0])
                sort_value_list_ascending.append(True)
            else:
                orderby_list.append(f'{two_tuple[0]} DESC')
                sort_value_list_by.append(two_tuple[0])
                sort_value_list_ascending.append(False)
        orderby_query = ', '.join(orderby_list)
        
        cond_list = []
        sql_cond = []
        for con in conditions:
            col = con[0]
            if con[1] == '=':
                comp = '=='
            else:
                comp = con[1]
            comp_sql = con[1]
            value = con[2]
    
            if value.isnumeric() == False:
                condition = f'({table}[\'{col}\']{comp}\'{value}\')'
                sql_cond.append(f'{col} {comp_sql} \'{value}\'')
            else:
                condition = f'({table}[\'{col}\']{comp}{value})'
                sql_cond.append(f'{col} {comp_sql} {value}')
            cond_list.append(condition)
            
        for i in range(len(bool_comp)):
            if bool_comp[i] == 'and':
                bool_comp[i] = '&'
            elif bool_comp[i] == 'or':
                bool_comp[i] = '|'
                
        #combine the multiple projection into one string
        projection_clause = [None] * (len(cond_list)+len(bool_comp))
        projection_clause[::2] = cond_list
        projection_clause[1::2] = bool_comp
        combined_cond = ' '.join(projection_clause)
        
        bool_comp_sql = ['AND' if x=='&' or x=='and' else 'OR' for x in bool_comp]
        sql_where_clause =  [None] * (len(sql_cond)+len(bool_comp_sql))
        sql_where_clause[::2] = sql_cond
        sql_where_clause[1::2] = bool_comp_sql
        combined_sql_where_clause = ' '.join(sql_where_clause)
        
        groupby_list = ', '.join(groupby_cond)
        
        #append command
        if projection[0] == '*':
            commands.append(f'{table}[{combined_cond}].sort_values(by={sort_value_list_by}, ascending={sort_value_list_ascending}).groupby({groupby_cond})')
            query = f'SELECT * FROM {table} WHERE {combined_sql_where_clause} GROUP BY {groupby_list} ORDER BY {orderby_query};'

            
            result = query
            cursor.execute(query)
            data44 =  cursor.fetchall()
        else:
            #get result
            projection_list = ', '.join(projection)
            commands.append(f'{table}[{combined_cond}].sort_values(by={sort_value_list_by}, ascending={sort_value_list_ascending}).groupby({groupby_cond})[{projection}]')
            query = f'SELECT {projection_list} FROM {table} WHERE {combined_sql_where_clause} GROUP BY {groupby_list} ORDER BY {orderby_query};'

            result = query
            cursor.execute(query)
            data44 =  cursor.fetchall()

    return render_template('customer_home.html', trans_table4 = table,trans_pro4 = projection,cond133 = con1,cond233=con2,cond333=con3,cond433=con4,cond533=con5,cond633=con6,bool33=bool_c,co333 = commands[0],result4 = result,group_c3 = group,order = orderby,coll = col,data_tran4 = data44)

@app.route('/customer_home_s1',methods=['GET', 'POST'])
def from_natural_to_spark_projection():
    cursor = conn.cursor()
    table = request.form['table_s1']
    projection = request.form['pro_s1']
    projection = projection.split(',')
    
    commands = [] # a list that holds all possible commands
    result = None # an object that holds the result after executing the command
    error = False
    
    #get all columns name
    all_columns_query = f'select column_name from information_schema.columns where table_name=\'{table}\''
    cursor.execute(all_columns_query)
    all_columns_result = cursor.fetchall()
    columns_df = pd.DataFrame(all_columns_result)
    all_columns = list(columns_df[0])


    #error checking
    if isinstance(projection, list):
        for column in projection:
            if column not in all_columns and column!='*':
                commands.append(f'error: specified column name {column} does not exist')
                error = True
                break
    else:
        commands.append(f'error: wrong column type passed, can be either str or list, got {type(projection)}')
        error = True
        
    if error == True:
        return render_template('customer_home.html', table_s1 = table, pro_s1 = projection, s1 = commands[0])

    if error == False:
        if projection[0] == '*':
            commands.append(f'{table}.show()')
            projection_list = ', '.join(projection)
            query = f'SELECT * FROM {table};'
            result = query
            cursor.execute(query)
            datas1 =  cursor.fetchall()
            
        else:
            commands.append(f'{table}[{projection}]')
            projection_list = ', '.join(projection)
            query = f'SELECT {projection_list} FROM {table};'
            result = query
            cursor.execute(query)
            datas1 =  cursor.fetchall()
            
    return render_template('customer_home.html', table_s1 = table, pro_s1 = projection, s1 = commands[0],data_s1 = datas1)

@app.route('/customer_home_s2',methods=['GET', 'POST'])
def from_natural_to_spark_projection_condition():

    cursor = conn.cursor()
    table = request.form['table_s2']
    projection = request.form['pro_s2']
    projection = projection.split(',')
    con1 = request.form['conds1']
    con2 = request.form['conds2']
    con3 = request.form['conds3']
    tuple1 = (con1,con2,con3)
    
    con4 = request.form['conds4']
    con5 = request.form['conds5']
    con6 = request.form['conds6']
    tuple2 = (con4,con5,con6)
    
    conditions = []
    conditions.append(tuple1)
    conditions.append(tuple2)
    
    bool_c = request.form['bools1']
    bool_comp = []
    bool_comp.append(bool_c)
    


    commands = [] # a list that holds all possible commands
    result = None # an object that holds the result after executing the command
    error = False
    
    #get all columns name
    all_columns_query = f'select column_name from information_schema.columns where table_name=\'{table}\''
    cursor.execute(all_columns_query)
    all_columns_result = cursor.fetchall()
    columns_df = pd.DataFrame(all_columns_result)
    all_columns = list(columns_df[0])
    
    relation_dict = {'less than':'<', 'greater than':'>', 'equal to':'==',                    'less than equal':'<=', 'greater than equal':'>='}
    comp_dict = {'and':'&', 'or':'|'}
    
    relation_dict_sql = {'less than':'<', 'greater than':'>', 'equal to':'=',                    'less than equal':'<=', 'greater than equal':'>='}
    comp_dict_sql = {'and':'AND', 'OR':'|'}

    #error checking
    if isinstance(projection, list):
        for column in projection:
            if column not in all_columns and column!='*':
                commands.append(f'error: specified column name {column} does not exist')
                error = True
                break
    else:
        commands.append(f'error: wrong column type passed, can be either str or list, got {type(projection)}')
        error = True

    #error checking for conditions
    if isinstance(conditions, list):
        for three_tuple in conditions:
            if three_tuple[0] not in all_columns:
                commands.append(f'error: specified column name \'{three_tuple[0]}\' in {three_tuple} does not exist in the table')
                error = True
            if three_tuple[1] not in ['greater than', 'equal to', 'less than', 'greater than equal', 'less than equal']:
                commands.append(f'error: invalid unary operator \'{three_tuple[1]}\' in {three_tuple}')
                error = True
    else:
        commands.append(f'error: conditions must be a list, got \'{type(conditions)}\' instead.')
        error = True

    #error checking for bool_comp
    if isinstance(bool_comp, list):
        if len(bool_comp) != len(conditions) - 1:
            commands.append(f'error: conditions have to be one more than boolean operators')
            error = True
        else:
            for bool_operator in bool_comp:
                if bool_operator not in ['and', 'or']:
                    commands.append(f'error: invalid boolean operator, expect and or or, got \'{bool_operator}\' instead.')
                    error = True
                    break
    else:
        commands.append(f'error: bool_comp must be a list, got \'{type(bool_comp)}\' instead.')
        error = True
        
    if error == True:
        return render_template('customer_home.html', table_s2 = table, pro_s2 = projection,conds1 = con1,conds2=con2,conds3=con3,conds4=con4,conds5=con5,conds6=con6,bools1=bool_c,s2 = commands[0])
 
    #translation
    if error == False:
        cond_list = []
        sql_cond = []
        for con in conditions:
            col = con[0]
            comp = relation_dict[con[1]]
            comp_sql = relation_dict_sql[con[1]]
            value = con[2]
    
            if value.isnumeric() == False:
                condition = f'({table}[\'{col}\']{comp}\'{value}\')'
                sql_cond.append(f'{col} {comp_sql} \'{value}\'')
            else:
                condition = f'({table}[\'{col}\']{comp}{value})'
                sql_cond.append(f'{col} {comp_sql} {value}')
            cond_list.append(condition)
            
        for i in range(len(bool_comp)):
            if bool_comp[i] == 'and':
                bool_comp[i] = '&'
            elif bool_comp[i] == 'or':
                bool_comp[i] = '|'
                
        #combine the multiple projection into one string
        projection_clause = [None] * (len(cond_list)+len(bool_comp))
        projection_clause[::2] = cond_list
        projection_clause[1::2] = bool_comp
        combined_cond = ' '.join(projection_clause)
        
        bool_comp_sql = ['AND' if x=='and' else 'OR' for x in bool_comp]
        sql_where_clause =  [None] * (len(sql_cond)+len(bool_comp_sql))
        sql_where_clause[::2] = sql_cond
        sql_where_clause[1::2] = bool_comp_sql
        combined_sql_where_clause = ' '.join(sql_where_clause)
        #append command
        
        projection_list = ', '.join(projection)
        if projection_list[0] == '*':
            commands.append(f'{table}[{combined_cond}]')
            query = f'SELECT * FROM {table} WHERE {combined_sql_where_clause};'
            projection = all_columns
        else:
            commands.append(f'{table}[{combined_cond}][{projection}]')
            query = f'SELECT {projection_list} FROM {table} WHERE {combined_sql_where_clause};'
        cursor.execute(query)
        datas2 =  cursor.fetchall()
        result = query
        
            
    return render_template('customer_home.html', table_s2 = table, pro_s2 = projection,conds1 = con1,conds2=con2,conds3=con3,conds4=con4,conds5=con5,conds6=con6,bools1=bool_c,s2 = commands[0],data_s2 = datas2)
 
 
@app.route('/customer_home_s3',methods=['GET', 'POST'])
def from_natural_to_spark_projection_condition_sort():
 
    cursor = conn.cursor()
    table = request.form['table_s3']
    projection = request.form['pro_s3']
    projection = projection.split(',')
    con1 = request.form['conds13']
    con2 = request.form['conds23']
    con3 = request.form['conds33']
    tuple1 = (con1,con2,con3)
    
    con4 = request.form['conds43']
    con5 = request.form['conds53']
    con6 = request.form['conds63']
    tuple2 = (con4,con5,con6)
    
    conditions = []
    conditions.append(tuple1)
    conditions.append(tuple2)
    
    bool_c = request.form['bools2']
    bool_comp = []
    bool_comp.append(bool_c)
    
    
    col = request.form['col3']
    orderby = request.form['order3']
    orderby_cond = []
    if orderby == 'ASC':
        tuple = (col,True)
        orderby_cond.append(tuple)
    elif orderby == 'DESC':
        tuple = (col,False)
        orderby_cond.append(tuple)
    
    commands = [] # a list that holds all possible commands
    result = None # an object that holds the result after executing the command
    error = False
    
    #get all columns name
    all_columns_query = f'select column_name from information_schema.columns where table_name=\'{table}\''
    cursor.execute(all_columns_query)
    all_columns_result = cursor.fetchall()
    columns_df = pd.DataFrame(all_columns_result)
    all_columns = list(columns_df[0])
    
    relation_dict = {'less than':'<', 'greater than':'>', 'equal to':'==',                    'less than equal':'<=', 'greater than equal':'>='}
    comp_dict = {'and':'&', 'or':'|'}
    
    relation_dict_sql = {'less than':'<', 'greater than':'>', 'equal to':'=',                    'less than equal':'<=', 'greater than equal':'>='}
    comp_dict_sql = {'and':'AND', 'OR':'|'}

    #error checking
    if isinstance(projection, list):
        for column in projection:
            if column not in all_columns and column!='*':
                commands.append(f'error: specified column name {column} does not exist')
                error = True
                break
    else:
        commands.append(f'error: wrong column type passed, can be either str or list, got {type(projection)}')
        error = True

    #error checking for conditions
    if isinstance(conditions, list):
        for three_tuple in conditions:
            if three_tuple[0] not in all_columns:
                commands.append(f'error: specified column name \'{three_tuple[0]}\' in {three_tuple} does not exist in the table')
                error = True
            if three_tuple[1] not in ['greater than', 'equal to', 'less than', 'greater than equal', 'less than equal']:
                commands.append(f'error: invalid unary operator \'{three_tuple[1]}\' in {three_tuple}')
                error = True
    else:
        commands.append(f'error: conditions must be a list, got \'{type(conditions)}\' instead.')
        error = True

    #error checking for bool_comp
    if isinstance(bool_comp, list):
        if len(bool_comp) != len(conditions) - 1:
            commands.append(f'error: conditions have to be one more than boolean operators')
            error = True
        else:
            for bool_operator in bool_comp:
                if bool_operator not in ['and', 'or']:
                    commands.append(f'error: invalid boolean operator, expect and or or, got \'{bool_operator}\' instead.')
                    error = True
                    break
    else:
        commands.append(f'error: bool_comp must be a list, got \'{type(bool_comp)}\' instead.')
        error = True
        
    '''
        

    #error checking for orderby_cond
    if isinstance(orderby_cond, list):
        for two_tuple in orderby_cond:
            if not isinstance(two_tuple, tuple):
                commands.append(f'error: each element in the list must be a two-tuple, got {type(two_tuple)} instead.')
                error = True
    else:
        commands.append(f'error: orderby_cond must be a list of column names and boolean values, got {type(orderby_cond)} instead.')
        error = True
    '''
    if error == True:
        return render_template('customer_home.html', table_s3 = table, pro_s3 = projection,conds13 = con1,conds23=con2,conds33=con3,conds43=con4,conds53=con5,conds63=con6,bools2=bool_c,s3 = commands[0])
    #translation
    if error == False:
        sort_column, sort_asce = [],[]
        for two_tuple in orderby_cond:
            sort_column.append(two_tuple[0])
            sort_asce.append(two_tuple[1])
    
        orderby_list = []
        for two_tuple in orderby_cond:
            if two_tuple[1] == True:
                orderby_list.append(f'{two_tuple[0]} ASC')
            else:
                orderby_list.append(f'{two_tuple[0]} DESC')
        orderby_query = ', '.join(orderby_list)
    
        cond_list = []
        sql_cond = []
        for con in conditions:
            col = con[0]
            comp = relation_dict[con[1]]
            comp_sql = relation_dict_sql[con[1]]
            value = con[2]
    
            if value.isnumeric() == False:
                condition = f'({table}[\'{col}\']{comp}\'{value}\')'
                sql_cond.append(f'{col} {comp_sql} \'{value}\'')
            else:
                condition = f'({table}[\'{col}\']{comp}{value})'
                sql_cond.append(f'{col} {comp_sql} {value}')
            cond_list.append(condition)

        for i in range(len(bool_comp)):
            if bool_comp[i] == 'and':
                bool_comp[i] = '&'
            elif bool_comp[i] == 'or':
                bool_comp[i] = '|'
                
        #combine the multiple projection into one string
        projection_clause = [None] * (len(cond_list)+len(bool_comp))
        projection_clause[::2] = cond_list
        projection_clause[1::2] = bool_comp
        combined_cond = ' '.join(projection_clause)
        
        bool_comp_sql = ['AND' if x=='and' else 'OR' for x in bool_comp]
        sql_where_clause =  [None] * (len(sql_cond)+len(bool_comp_sql))
        sql_where_clause[::2] = sql_cond
        sql_where_clause[1::2] = bool_comp_sql
        combined_sql_where_clause = ' '.join(sql_where_clause)
        #append command
        
        projection_list = ', '.join(projection)
        if projection_list[0] == '*':
            commands.append(f'{table}[{combined_cond}].sort({sort_column}, ascending={sort_asce})')
            query = f'SELECT * FROM {table} WHERE {combined_sql_where_clause} ORDER BY {orderby_query};'
            projection = all_columns
        else:
            commands.append(f'{table}[{combined_cond}][{projection}].sort({sort_column}, ascending={sort_asce})')
            query = f'SELECT {projection_list} FROM {table} WHERE {combined_sql_where_clause} ORDER BY {orderby_query};'
        cursor.execute(query)
        datas3 =  cursor.fetchall()
        result = query
        
            
    return render_template('customer_home.html', table_s3 = table, pro_s3 = projection,conds13 = con1,conds23=con2,conds33=con3,conds43=con4,conds53=con5,conds63=con6,bools2=bool_c,s3 = commands[0],data_s3 = datas3)

@app.route('/customer_home_s4',methods=['GET', 'POST'])
def from_natural_to_spark_groupby_agg():
    cursor = conn.cursor()
    table = request.form['table_s4']
    groupby_cond = request.form['group_s3']
    groupby_cond = groupby_cond.split(',')
    
    con1 = request.form['conds133']
    con2 = request.form['conds233']
    con3 = request.form['conds333']
    tuple1 = (con1,con2)
    
    con4 = request.form['conds433']
    tuple2 = (con3,con4)
    
    agg_cond = []
    agg_cond.append(tuple1)
    agg_cond.append(tuple2)

    

    commands = [] # a list that holds all possible commands
    result = None # an object that holds the result after executing the command
    error = False
        
    #get all columns name
    all_columns_query = f'select column_name from information_schema.columns where table_name=\'{table}\''
    cursor.execute(all_columns_query)
    all_columns_result = cursor.fetchall()
    columns_df = pd.DataFrame(all_columns_result)
    all_columns = list(columns_df[0])
        
    #error checking for groupby
    if isinstance(groupby_cond, list):
        for column_name in groupby_cond:
            if column_name not in all_columns:
                commands.append(f'error: specified column name \'{column_name}\' does not exist in the table')
                error = True
    else:
        commands.append(f'error: groupby_cond must be a list of column names, got {type(groupby_cond)} instead.')
        error = True
        
    #error checking for aggregation function
    if isinstance(agg_cond, list):
        for two_tuple in agg_cond:
            if isinstance(two_tuple, tuple):
                if two_tuple[0] not in all_columns:
                    commands.append(f'error: specified column name {two_tuple[0]} does not exist.')
                    error = True
                elif two_tuple[1] not in ['min','max','avg','count','sum']:
                    commands.append(f'error: invalid agg function \'{agg}\'.')
                    error = True
            else:
                commands.append(f'error: elements in the list must be two-tuples, got {type(two_tuple)} instead.')
                error = True
    else:
        commands.append(f'error: agg functions must be a list, got {type(agg)} instead.')
        error = True
        
    if error == True:
        return render_template('customer_home.html', table_s4 = table, group_s3 = groupby_cond,conds133 = con1,conds233=con2,conds333=con3,conds433=con4,s4 = commands[0], s44 = commands[1])
    #translation
    if error == False:
        groupby_clause = ', '.join(groupby_cond)
        agg_list = []
        agg_list_command = []
        for agg_tuple in agg_cond:
            col = agg_tuple[0]
            agg_func = agg_tuple[1]
            agg_list.append(f'{agg_func.upper()}({col})')
            agg_list_command.append(f'fc.{agg_func}(\'{col}\')')
        agg_str = ', '.join(agg_list_command)
        agg_clause = ', '.join(agg_list)
            
        query = f'SELECT {agg_clause} FROM {table} GROUP BY {groupby_clause};'
        result = query
       
        #append commands
        commands.append('import pyspark.sql.functions as fc')
        commands.append(f'{table}.groupby({groupby_cond}).agg({agg_str})')
        
        cursor.execute(query)
        datas4 =  cursor.fetchall()


        
            
    return render_template('customer_home.html', table_s4 = table, group_s3 = groupby_cond,conds133 = con1,conds233=con2,conds333=con3,conds433=con4,s4 = commands[0], s44 = commands[1], data_s4 = datas4)

@app.route('/customer_home_s5',methods=['GET', 'POST'])
def from_natural_to_spark_agg():

    cursor = conn.cursor()
    table = request.form['table_s5']
    
    con1 = request.form['conds1333']
    con2 = request.form['conds2333']
    con3 = request.form['conds3333']
    tuple1 = (con1,con2)
    
    con4 = request.form['conds4333']
    tuple2 = (con3,con4)
    
    agg_cond = []
    agg_cond.append(tuple1)
    agg_cond.append(tuple2)

    
    commands = [] # a list that holds all possible commands
    result = None # an object that holds the result after executing the command
    error = False
    
    #get all columns name
    all_columns_query = f'select column_name from information_schema.columns where table_name=\'{table}\''
    cursor.execute(all_columns_query)
    all_columns_result = cursor.fetchall()
    columns_df = pd.DataFrame(all_columns_result)
    all_columns = list(columns_df[0])
 
    #error checking for aggregation function
    if isinstance(agg_cond, list):
        for two_tuple in agg_cond:
            if isinstance(two_tuple, tuple):
                if two_tuple[0] not in all_columns:
                    commands.append(f'error: specified column name {two_tuple[0]} does not exist.')
                    error = True
                elif two_tuple[1] not in ['min','max','avg','count','sum']:
                    commands.append(f'error: invalid agg function ')
                    error = True
            else:
                commands.append(f'error: elements in the list must be two-tuples, got {type(two_tuple)} instead.')
                error = True
    else:
        commands.append(f'error: agg functions must be a list, got {type(agg)} instead.')
        error = True
        
    if error == True:
        return render_template('customer_home.html', table_s5 = table, conds1333 = con1, conds2333=con2, conds3333=con3, conds4333=con4,s5 = commands[0], s55 = commands[1])
    #translation
    if error == False:
        agg_list = []
        agg_list_command = []
        for agg_tuple in agg_cond:
            col = agg_tuple[0]
            agg_func = agg_tuple[1]
            agg_list.append(f'{agg_func.upper()}({col})')
            agg_list_command.append(f'fc.{agg_func}(\'{col}\')')
        agg_str = ', '.join(agg_list_command)
        agg_clause = ', '.join(agg_list)
            
        query = f'SELECT {agg_clause} FROM {table};'
        result = query
       
        #append commands
        commands.append('import pyspark.sql.functions as fc')
        commands.append(f'{table}.agg({agg_str})')
        
        cursor.execute(query)
        datas5 =  cursor.fetchall()


        
            
    return render_template('customer_home.html', table_s5 = table, conds1333 = con1, conds2333=con2, conds3333=con3, conds4333=con4,s5 = commands[0], s55 = commands[1], data_s5 = datas5)
    
    
@app.route('/customer_home_p1',methods=['GET', 'POST'])

def from_pandas_to_sql_all():
    try:
        cursor = conn.cursor()
        table = request.form['table_p1']
        commands = [] # a list that holds all possible commands
        result = None # an object that holds the result after executing the command
        error = False
            
        commands.append(f'SELECT * FROM {table}')
        result = f'SELECT * FROM {table}'
        cursor.execute(result)
        datap1 =  cursor.fetchall()
            
        return render_template('customer_home.html', table_p1 = table, p1 = commands[0], data_p1 = datap1)
    except:
        return render_template('customer_home.html')

    
@app.route('/customer_home_p2',methods=['GET', 'POST'])
def from_pandas_to_sql_projection():
    try:
        cursor = conn.cursor()
        table = request.form['table_p2']
        projection = request.form['pro_p2']

        commands = [] # a list that holds all possible commands
        result = None # an object that holds the result after executing the command
        error = False

        commands.append(f'SELECT {projection} FROM {table}')
        result = f'SELECT {projection} FROM {table}'
        cursor.execute(result)
        datap2 =  cursor.fetchall()
        return render_template('customer_home.html', table_p2 = table, p2 = commands[0], data_p2 = datap2)
        
    except:
        return render_template('customer_home.html')

@app.route('/customer_home_p3',methods=['GET', 'POST'])
def from_pandas_to_sql_projection_single_condition():
    try:
        cursor = conn.cursor()
        table = request.form['table_p3']
        projection = request.form['pro_p3']
        cond_col =request.form['col_p3']
        cond_comp = request.form['comp_p3']
        cond_val = request.form['val_p3']
        
        commands = [] # a list that holds all possible commands
        result = None # an object that holds the result after executing the command
        error = False
        if cond_comp =='==':
                cond_comp = '='
        if cond_val.isnumeric() == True:
            query = f'SELECT {projection} FROM {table} WHERE {cond_col} {cond_comp} {cond_val}'
        else:
            query = f'SELECT {projection} FROM {table} WHERE {cond_col} {cond_comp} \'{cond_val}\''
        print(query)
        commands.append(query)
        result = query
        cursor.execute(result)
        datap3 =  cursor.fetchall()
        
        return render_template('customer_home.html', table_p3 = table, p3 = commands[0], data_p3 = datap3,pro_p3 = projection, col_p3=cond_col, comp_p3=cond_comp, val_p3=cond_val)
        
    except:
        return render_template('customer_home.html')
        
@app.route('/customer_home_p4',methods=['GET', 'POST'])
def from_pandas_to_sql_projection_multi_condition():
    try:
        cursor = conn.cursor()
        table = request.form['table_p4']
        projection = request.form['pro_p4']
        cond_col1 =request.form['col_p4']
        cond_comp1 = request.form['comp_p4']
        cond_val1 = request.form['val_p4']
        boolean = request.form['bool_p4']
        cond_col2 =request.form['col_p42']
        cond_comp2 = request.form['comp_p42']
        cond_val2 = request.form['val_p42']
        commands = [] # a list that holds all possible commands
        result = None # an object that holds the result after executing the command
        error = False

        if cond_comp1 =='==':
            cond_comp1 = '='

        if cond_comp2 =='==':
            cond_comp2 = '='
            
        if boolean=='&':
            boolean = 'AND'
        else:
            boolean = 'OR'
        

            
        if cond_val1.isnumeric() == True and cond_val2.isnumeric() == True:
            query = f'SELECT {projection} FROM {table} WHERE {cond_col1} {cond_comp1} {cond_val1} {boolean} {cond_col2} {cond_comp2} {cond_val2}'
        elif cond_val1.isnumeric() == False and cond_val2.isnumeric() == True:
            query = f'SELECT {projection} FROM {table} WHERE {cond_col1} {cond_comp1} \'{cond_val1}\' {boolean} {cond_col2} {cond_comp2} {cond_val2}'
        elif cond_val1.isnumeric() == True and cond_val2.isnumeric() == False:
            query = f'SELECT {projection} FROM {table} WHERE {cond_col1} {cond_comp1} {cond_val1} {boolean} {cond_col2} {cond_comp2} \'{cond_val2}\''
        else:
            query = f'SELECT {projection} FROM {table} WHERE {cond_col1} {cond_comp1} \'{cond_val1}\' {boolean} {cond_col2} {cond_comp2} \'{cond_val2}\''

        commands.append(query)
        result = query
        cursor.execute(result)
        datap4 =  cursor.fetchall()
    
        return render_template('customer_home.html', table_p4 = table, p4 = commands[0], data_p4 = datap4,pro_p4 = projection, col_p4=cond_col1, comp_p4=cond_comp1, val_p4=cond_val1, col_p42=cond_col2, comp_p42 =cond_comp2, val_p42=cond_val2)

    except:
        return render_template('customer_home.html')
        
        
@app.route('/customer_home_p5',methods=['GET', 'POST'])
def from_pandas_to_sql_groupby_agg():
    try:
        cursor = conn.cursor()
        table = request.form['table_p5']
        groupby = request.form['group_p5']
        name = request.form['as_name']
        agg_col = request.form['agg_colp4']
        agg_func = request.form['agg_funcp4']
        
        commands = [] # a list that holds all possible commands
        result = None # an object that holds the result after executing the command
        error = False
        
        agg_dict = {'max':'MAX', 'min':'MIN', 'mean':'AVG', 'count':'COUNT', 'sum':'SUM'}
        
        query = f'SELECT {agg_dict[agg_func]}({agg_col}) AS {name} FROM {table} GROUP BY {groupby}'
        commands.append(query)
        result = query
        cursor.execute(result)
        datap5 =  cursor.fetchall()
        
        return render_template('customer_home.html', table_p5 = table, p5 = commands[0], data_p5 = datap5,group_p5 = groupby, as_name = name, agg_colp4 = agg_col, agg_funcp4 = agg_func)
    except:
        return render_template('customer_home.html')
        
@app.route('/customer_home_p6',methods=['GET', 'POST'])
def from_pandas_to_sql_sort():
    try:
        cursor = conn.cursor()
        table = request.form['table_p6']
        sort_by = request.form['sort_p6']
        ascending = request.form['asc_p6']
        commands = [] # a list that holds all possible commands
        result = None # an object that holds the result after executing the command
        error = False
        
        boolean_dict = {'True':'ASC', 'False':'DESC'}
        
        sort_by_list = [col.strip() for col in sort_by.split(',')]
        ascending_list_str = [boolean.strip() for boolean in ascending.split(',')]
        ascending_list = [boolean_dict[x] for x in ascending_list_str]
        
        pair_list = []
        for i in range(len(sort_by_list)):
            pair = sort_by_list[i] + ' ' + ascending_list[i]
            pair_list.append(pair)
        pair_str = ', '.join(pair_list)
        
        query = f'SELECT * FROM {table} ORDER BY {pair_str}'
        commands.append(query)
        result = query
        cursor.execute(result)
        datap6 =  cursor.fetchall()

        return render_template('customer_home.html', table_p6 = table, p6 = commands[0], data_p6 = datap6,sort_p6 = sort_by,asc_p6 = ascending)

    except:
        return render_template('customer_home.html')
        
@app.route('/customer_home_tran5',methods=['GET', 'POST'])
def from_sql_to_pandas_join():
    try:
        cursor = conn.cursor()
        table1 = request.form['t_table1']
        table2 = request.form['t_table2']
        how = request.form['way']
        table1_on = request.form['t_tableon1']
        table2_on = request.form['t_tableon2']

        commands = [] # a list that holds all possible commands
        result = None # an object that holds the result after executing the command
        error = False
        
        how_dict = {'JOIN':'inner', 'LEFT JOIN':'left', 'RIGHT JOIN':'right', 'FULL JOIN':'outer'}
        
        pd_how = how_dict[how]
        left_on = table1_on.split('.')[1]
        right_on = table2_on.split('.')[1]
        
        query = f'SELECT * FROM {table1} {how} {table2} ON {table1_on}={table2_on}'
        commands.append(f'pd.merge(how=\'{pd_how}\', left={table1}, right={table2}, left_on=\'{left_on}\', right_on=\'{right_on}\')')
        result = query
        cursor.execute(result)
        data_t5 =  cursor.fetchall()
        
        return render_template('customer_home.html', t_tableon1 = table1_on, t_tableon2 = table2_on, way = how, t_table1 = table1, t_table2 = table2, cot = commands[0], result5 = result, data_tran5 = data_t5)

    except:
        return render_template('customer_home.html')
        
@app.route('/logout')
def logout():
    try:
        session.pop('username')
        session.clear()
        print('cleared:',session)
        return redirect('/')
    except:
        session.pop('user')
        session.clear()
        print('cleared:',session)
        return redirect('/')

app.secret_key = 'some key that you will never guess'




if __name__ == "__main__":
    app.run('127.0.0.1', 5000, debug = True)
